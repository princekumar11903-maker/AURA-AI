export type AvatarState = 'idle' | 'listening' | 'thinking' | 'speaking';

export type LanguageMode = 'auto' | 'en' | 'hi' | 'hinglish';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  audioUrl?: string;
  isError?: boolean;
}

export interface UserSettings {
  language: LanguageMode;
  voiceName: string;
  voiceEngine: 'neural' | 'browser';
  speechOutputEnabled: boolean;
  hologramGlow: 'low' | 'med' | 'high';
  showScanlines: boolean;
  speechRate: number;
}

export interface SystemTelemetry {
  system: string;
  model: string;
  developer?: string;
  leadArchitect?: string;
  status: string;
  arcReactorOutput: string;
  neuralBandwidth: string;
  tacticalUptime: string;
}

export interface BatteryInfo {
  supported: boolean;
  level: number;
  charging: boolean;
}
