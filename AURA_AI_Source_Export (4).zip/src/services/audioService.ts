// Web Audio API and Speech Recognition Manager for AURA

type AmplitudeCallback = (amplitude: number, frequencies: Uint8Array) => void;

class AudioService {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private activeSource: AudioBufferSourceNode | MediaElementAudioSourceNode | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private animFrameId: number | null = null;
  private amplitudeListeners: Set<AmplitudeCallback> = new Set();
  
  // Speech Recognition state
  private recognition: any = null;
  public isListening: boolean = false;
  private silenceTimer: any = null;
  private simulatedMicTimer: any = null;

  private initAudioContext(): AudioContext {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  // Subscribe to audio amplitude for mouth movement & waveform
  public onAmplitude(callback: AmplitudeCallback): () => void {
    this.amplitudeListeners.add(callback);
    return () => {
      this.amplitudeListeners.delete(callback);
    };
  }

  public notifyAmplitude(amp: number, freqs: Uint8Array) {
    this.amplitudeListeners.forEach(cb => cb(amp, freqs));
  }

  // Play WAV / MP3 base64 with Web Audio analyser
  public async playAudioBase64(base64Data: string, mimeType: string = 'audio/wav'): Promise<void> {
    this.stopPlayback();
    const ctx = this.initAudioContext();
    this.isSpeaking = true;
    this.onSpeakingStateChange?.(true);

    try {
      const binaryString = window.atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Try AudioContext decodeAudioData
      let audioBuffer: AudioBuffer;
      try {
        audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
      } catch (decodeErr) {
        console.warn('AudioContext decode notice, falling back to Blob audio player:', decodeErr);
        const blob = new Blob([bytes], { type: mimeType });
        const blobUrl = URL.createObjectURL(blob);
        return await this.playViaAudioElement(blobUrl);
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.65;

      source.connect(analyser);
      analyser.connect(ctx.destination);

      this.analyser = analyser;
      this.activeSource = source;

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const trackAmplitude = () => {
        if (!this.analyser) {
          this.notifyAmplitude(0, new Uint8Array(bufferLength));
          return;
        }

        this.analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        const count = Math.min(32, bufferLength);
        for (let i = 2; i < count; i++) {
          sum += dataArray[i];
        }
        const avg = sum / (count - 2);
        const normalized = Math.min(1, avg / 128);

        this.notifyAmplitude(normalized, dataArray);
        this.animFrameId = requestAnimationFrame(trackAmplitude);
      };

      this.animFrameId = requestAnimationFrame(trackAmplitude);

      return new Promise<void>((resolve) => {
        source.onended = () => {
          this.stopPlayback();
          this.isSpeaking = false;
          this.onSpeakingStateChange?.(false);
          resolve();
        };
        source.start(0);
      });
    } catch (err) {
      console.warn('AudioContext playback error, falling back to audio element:', err);
      this.isSpeaking = false;
      this.onSpeakingStateChange?.(false);
    }
  }

  private playViaAudioElement(src: string): Promise<void> {
    return new Promise((resolve) => {
      this.stopPlayback();
      this.isSpeaking = true;
      this.onSpeakingStateChange?.(true);

      const audio = new Audio(src);
      this.currentAudioElement = audio;

      let simulatedTime = 0;
      const simInterval = setInterval(() => {
        simulatedTime += 0.15;
        const simulatedAmp = Math.sin(simulatedTime * 8) * 0.4 + 0.35 + (Math.random() * 0.2);
        this.notifyAmplitude(Math.max(0, simulatedAmp), new Uint8Array(32));
      }, 50);

      const cleanup = () => {
        clearInterval(simInterval);
        this.isSpeaking = false;
        this.onSpeakingStateChange?.(false);
        this.notifyAmplitude(0, new Uint8Array(32));
        resolve();
      };

      audio.onended = cleanup;
      audio.onerror = cleanup;

      audio.play().catch(() => {
        cleanup();
      });
    });
  }

  // Stream Queue for partial playback during text generation
  private speechQueue: Array<{ text: string; lang: string; rate: number }> = [];
  public isSpeaking: boolean = false;
  private isProcessingQueue: boolean = false;
  private speechAnimInterval: any = null;
  private onSpeakingStateChange: ((isSpeaking: boolean) => void) | null = null;
  private cachedVoices: SpeechSynthesisVoice[] = [];

  constructor() {
    this.initVoiceCache();
  }

  private initVoiceCache() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.cachedVoices = window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.cachedVoices = window.speechSynthesis.getVoices();
      };
    }
  }

  // Find optimal natural voice for Hindi / Indian speech
  public getOptimalVoice(langCode: string = 'hi-IN'): SpeechSynthesisVoice | null {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;

    let voices = this.cachedVoices;
    if (!voices || voices.length === 0) {
      voices = window.speechSynthesis.getVoices();
      this.cachedVoices = voices;
    }
    if (!voices || voices.length === 0) return null;

    // 1. Natural / Online Neural Hindi voices (Microsoft Swara Online, Google हिन्दी)
    const naturalHindiVoice = voices.find((v) => {
      const name = v.name.toLowerCase();
      const lang = v.lang.toLowerCase();
      const isHindi = lang.startsWith('hi') || name.includes('hindi') || name.includes('हिन्दी');
      const isNatural = name.includes('natural') || name.includes('online') || name.includes('google') || name.includes('swara') || name.includes('madhur');
      return isHindi && isNatural;
    });
    if (naturalHindiVoice) return naturalHindiVoice;

    // 2. Standard Hindi voices
    const hindiVoice = voices.find((v) =>
      v.lang.toLowerCase().startsWith('hi') ||
      v.name.toLowerCase().includes('hindi') ||
      v.name.toLowerCase().includes('हिन्दी') ||
      v.name.toLowerCase().includes('lekha') ||
      v.name.toLowerCase().includes('neerja') ||
      v.name.toLowerCase().includes('swara') ||
      v.name.toLowerCase().includes('madhur') ||
      v.name.toLowerCase().includes('kalpana')
    );
    if (hindiVoice) return hindiVoice;

    // 3. Natural / Online Indian English voice (trained on Indian accent, pronounces Hindi/Hinglish naturally)
    const naturalIndianVoice = voices.find((v) => {
      const name = v.name.toLowerCase();
      const lang = v.lang.toLowerCase();
      const isIndian = lang === 'en-in' || lang.includes('en_in') || name.includes('india');
      const isNatural = name.includes('natural') || name.includes('online') || name.includes('google') || name.includes('heera');
      return isIndian && isNatural;
    });
    if (naturalIndianVoice) return naturalIndianVoice;

    // 4. Any Indian English voice
    const indianVoice = voices.find((v) =>
      v.lang.toLowerCase() === 'en-in' ||
      v.lang.toLowerCase().includes('en_in') ||
      v.name.toLowerCase().includes('india') ||
      v.name.toLowerCase().includes('heera')
    );
    if (indianVoice) return indianVoice;

    // 5. Expressive female voice fallback
    const femaleVoice = voices.find((v) =>
      v.name.toLowerCase().includes('female') ||
      v.name.toLowerCase().includes('natural') ||
      v.name.toLowerCase().includes('zira') ||
      v.name.toLowerCase().includes('samantha') ||
      v.name.toLowerCase().includes('google')
    );
    return femaleVoice || voices[0] || null;
  }

  public setSpeakingStateListener(cb: (isSpeaking: boolean) => void) {
    this.onSpeakingStateChange = cb;
  }

  // Unlock audio context and resume speech synthesis on user touch/click
  public unlockAudio(): void {
    try {
      this.initAudioContext();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.resume();
      }
    } catch {
      // ignore
    }
  }

  // Vocalize with realistic Gemini Studio TTS or natural human fallback
  public async vocalizeRealisticSpeech(text: string, voiceName: string = 'Aoede'): Promise<void> {
    this.stopPlayback();
    this.unlockAudio();

    const cleanText = text
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/[`#_~]/g, '')
      .replace(/[-*•]\s+/g, '')
      .replace(/[✨⚡📥🔥🔊🤖💻📲★✓]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) return;

    this.isSpeaking = true;
    this.onSpeakingStateChange?.(true);

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanText, voiceName: voiceName || 'Aoede' }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          await this.playAudioBase64(data.audio, 'audio/wav');
          return;
        }
      }
    } catch (err) {
      console.warn('Neural TTS notice, using natural browser speech fallback:', err);
    }

    // High quality natural device voice fallback
    await this.speakBrowserSpeech(cleanText, 'hi-IN', 0.98);
  }

  // Enqueue a stream chunk to begin speaking immediately while generation continues
  public enqueueStreamChunk(text: string, lang: string = 'hi-IN', rate: number = 1.0): void {
    const cleanText = text.replace(/[*#_~`]/g, '').trim();
    if (!cleanText) return;

    this.speechQueue.push({ text: cleanText, lang: 'hi-IN', rate });

    if (!this.isProcessingQueue) {
      this.processNextInQueue();
    }
  }

  private processNextInQueue(): void {
    if (this.speechQueue.length === 0) {
      this.isProcessingQueue = false;
      this.isSpeaking = false;
      if (this.speechAnimInterval) {
        clearInterval(this.speechAnimInterval);
        this.speechAnimInterval = null;
      }
      this.notifyAmplitude(0, new Uint8Array(32));
      this.onSpeakingStateChange?.(false);
      return;
    }

    if (!('speechSynthesis' in window)) {
      this.speechQueue = [];
      this.isProcessingQueue = false;
      return;
    }

    this.isProcessingQueue = true;
    this.isSpeaking = true;
    this.onSpeakingStateChange?.(true);

    const nextItem = this.speechQueue.shift();
    if (!nextItem || !nextItem.text) {
      this.processNextInQueue();
      return;
    }

    try {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const utterance = new SpeechSynthesisUtterance(nextItem.text);
      utterance.lang = 'hi-IN'; // Always set Hindi language
      utterance.rate = nextItem.rate || 1.05;
      utterance.pitch = 1.05;

      const voice = this.getOptimalVoice('hi-IN');
      if (voice) {
        utterance.voice = voice;
      }

      let phase = 0;
      utterance.onstart = () => {
        if (this.speechAnimInterval) clearInterval(this.speechAnimInterval);
        this.speechAnimInterval = setInterval(() => {
          phase += 0.25;
          const amp = Math.abs(Math.sin(phase * 4.5)) * 0.7 + Math.random() * 0.25;
          this.notifyAmplitude(amp, new Uint8Array(32));
        }, 50);
      };

      utterance.onend = () => {
        this.processNextInQueue();
      };

      utterance.onerror = (e) => {
        console.warn('Utterance speech notice:', e);
        this.processNextInQueue();
      };

      window.speechSynthesis.speak(utterance);

      // Chrome/Edge auto-pause watchdog workaround
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    } catch (err) {
      console.warn('SpeechSynthesis error:', err);
      this.processNextInQueue();
    }
  }

  // Clear queued speech (e.g. when interrupted or a new prompt arrives)
  public clearSpeechQueue(): void {
    this.speechQueue = [];
    this.isProcessingQueue = false;
    this.isSpeaking = false;
    if (this.speechAnimInterval) {
      clearInterval(this.speechAnimInterval);
      this.speechAnimInterval = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.notifyAmplitude(0, new Uint8Array(32));
    this.onSpeakingStateChange?.(false);
  }

  // Instant Browser SpeechSynthesis for single utterances with natural cadence
  public speakBrowserSpeech(text: string, lang: string = 'hi-IN', rate: number = 0.98): Promise<void> {
    this.clearSpeechQueue();
    return new Promise((resolve) => {
      if (!('speechSynthesis' in window)) {
        this.isSpeaking = false;
        this.onSpeakingStateChange?.(false);
        resolve();
        return;
      }

      this.stopPlayback();
      window.speechSynthesis.cancel();

      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'hi-IN'; // Strictly Hindi phonetics
      utterance.rate = rate; // 0.98 natural conversational cadence
      utterance.pitch = 1.0; // 1.0 natural human pitch

      const selectedVoice = this.getOptimalVoice('hi-IN');
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }

      this.isSpeaking = true;
      this.onSpeakingStateChange?.(true);

      let timer: any = null;
      utterance.onstart = () => {
        this.isSpeaking = true;
        this.onSpeakingStateChange?.(true);
        let phase = 0;
        timer = setInterval(() => {
          phase += 0.25;
          const amp = Math.abs(Math.sin(phase * 4.5)) * 0.7 + Math.random() * 0.25;
          this.notifyAmplitude(amp, new Uint8Array(32));
        }, 50);
      };

      utterance.onend = () => {
        if (timer) clearInterval(timer);
        this.isSpeaking = false;
        this.onSpeakingStateChange?.(false);
        this.notifyAmplitude(0, new Uint8Array(32));
        resolve();
      };

      utterance.onerror = () => {
        if (timer) clearInterval(timer);
        this.isSpeaking = false;
        this.onSpeakingStateChange?.(false);
        this.notifyAmplitude(0, new Uint8Array(32));
        resolve();
      };

      window.speechSynthesis.speak(utterance);

      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    });
  }

  public stopPlayback(): void {
    this.clearSpeechQueue();
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.activeSource) {
      try {
        if ('stop' in this.activeSource && typeof (this.activeSource as any).stop === 'function') {
          (this.activeSource as any).stop();
        }
        this.activeSource.disconnect();
      } catch (e) {
        // ignore
      }
      this.activeSource = null;
    }
    if (this.currentAudioElement) {
      this.currentAudioElement.pause();
      this.currentAudioElement = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.analyser = null;
    this.notifyAmplitude(0, new Uint8Array(32));
  }

  // Robust Speech Recognition (Web Speech API) with single-dispatch safeguard & snappy 650ms timeout
  public startSpeechRecognition(
    lang: string,
    onInterim: (text: string) => void,
    onFinal: (text: string) => void,
    onError: (error: string) => void,
    onEnd: () => void,
    onSoundLevel: (level: number, freqs: Uint8Array) => void
  ): boolean {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      onError('Speech Recognition is not supported in this browser. Please use Chrome/Edge or type your message.');
      return false;
    }

    try {
      this.stopSpeechRecognition();
      this.unlockAudio();

      const rec = new SpeechRec();
      rec.continuous = false; // Capture complete user utterance
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      // Always use 'hi-IN' so Hindi, Hinglish, and mixed Indian commands are recognized natively
      rec.lang = 'hi-IN';

      let accumulatedFinal = '';
      let latestInterim = '';
      let hasDispatched = false;

      const dispatchFinal = (finalText: string) => {
        if (hasDispatched) return;
        const cleaned = finalText.trim();
        if (cleaned) {
          hasDispatched = true;
          accumulatedFinal = '';
          latestInterim = '';
          this.stopSpeechRecognition();
          onFinal(cleaned);
        }
      };

      // Live waveform simulation driven by recognition events
      let soundEnergy = 0.2;
      const dummyFreqs = new Uint8Array(32);
      this.simulatedMicTimer = setInterval(() => {
        soundEnergy += (Math.random() * 0.4 - 0.2);
        soundEnergy = Math.max(0.15, Math.min(0.9, soundEnergy));
        for (let i = 0; i < 32; i++) {
          dummyFreqs[i] = Math.floor(soundEnergy * 180 + Math.sin(i + Date.now() / 100) * 40);
        }
        onSoundLevel(soundEnergy, dummyFreqs);
      }, 70);

      rec.onstart = () => {
        this.isListening = true;
        soundEnergy = 0.4;
      };

      rec.onsoundstart = () => {
        soundEnergy = 0.75;
      };

      rec.onspeechstart = () => {
        soundEnergy = 0.95;
      };

      rec.onspeechend = () => {
        soundEnergy = 0.25;
      };

      rec.onresult = (event: any) => {
        soundEnergy = 0.9;
        latestInterim = '';
        
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          const transcriptChunk = item[0]?.transcript || '';
          if (item.isFinal) {
            accumulatedFinal += (accumulatedFinal ? ' ' : '') + transcriptChunk;
          } else {
            latestInterim += transcriptChunk;
          }
        }

        const currentDisplay = (accumulatedFinal + ' ' + latestInterim).trim();
        if (currentDisplay) {
          onInterim(currentDisplay);
        }

        // Fast 650ms debounce silence timer for snappy reply turnaround
        if (this.silenceTimer) clearTimeout(this.silenceTimer);
        this.silenceTimer = setTimeout(() => {
          const finishedText = (accumulatedFinal || latestInterim).trim();
          if (finishedText && this.isListening && !hasDispatched) {
            dispatchFinal(finishedText);
          }
        }, 650);
      };

      rec.onerror = (event: any) => {
        console.warn('Speech recognition event:', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          onError('Microphone permission blocked. Please enable microphone permissions in your browser.');
        } else if (event.error === 'no-speech') {
          onInterim('');
        } else if (event.error !== 'aborted') {
          onError(`Mic error: ${event.error}`);
        }
        this.isListening = false;
      };

      rec.onend = () => {
        this.stopWaveSimulation();
        this.isListening = false;

        const finalTextToSend = (accumulatedFinal || latestInterim).trim();
        if (finalTextToSend && !hasDispatched) {
          dispatchFinal(finalTextToSend);
        } else if (!hasDispatched) {
          onEnd();
        }
      };

      this.recognition = rec;
      rec.start();
      return true;
    } catch (err: any) {
      console.error('Speech recognition start error:', err);
      onError(`Failed to start mic: ${err?.message || err}`);
      this.isListening = false;
      return false;
    }
  }

  private stopWaveSimulation() {
    if (this.simulatedMicTimer) {
      clearInterval(this.simulatedMicTimer);
      this.simulatedMicTimer = null;
    }
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
  }

  public stopSpeechRecognition(): void {
    this.stopWaveSimulation();
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.recognition = null;
    }
    this.isListening = false;
  }
}

export const audioService = new AudioService();
