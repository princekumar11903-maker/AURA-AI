import { ChatMessage, LanguageMode, SystemTelemetry } from '../types';

export async function streamMessageFromGemini(
  message: string,
  history: ChatMessage[],
  language: LanguageMode,
  onChunk: (chunk: string) => void
): Promise<string> {
  try {
    const res = await fetch('/api/chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        history: history.map((m) => ({
          role: m.role,
          text: m.text,
        })),
        language,
      }),
    });

    if (!res.ok || !res.body) {
      const fallback = await sendMessageToGemini(message, history, language);
      onChunk(fallback);
      return fallback;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith('data: ')) continue;
        const dataStr = trimmed.slice(6);
        if (dataStr === '[DONE]') continue;

        try {
          const parsed = JSON.parse(dataStr);
          if (parsed.text) {
            fullText += parsed.text;
            onChunk(parsed.text);
          }
        } catch {
          // ignore partial JSON parse errors
        }
      }
    }

    return fullText || "Systems active, Sir.";
  } catch (err) {
    console.warn('Streaming failed, fallback to unary message:', err);
    const fallback = await sendMessageToGemini(message, history, language);
    onChunk(fallback);
    return fallback;
  }
}

export async function sendMessageToGemini(
  message: string,
  history: ChatMessage[],
  language: LanguageMode
): Promise<string> {
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        history: history.map((m) => ({
          role: m.role,
          text: m.text,
        })),
        language,
      }),
    });

    if (!res.ok) {
      return language === 'hi'
        ? "हाँ सर, सिस्टम स्थानीय मोड में सक्रिय है। आपका आदेश क्या है?"
        : language === 'hinglish'
        ? "Haan Boss, auxiliary systems active hain. Bataiye kya directive hai?"
        : "Auxiliary power nominal, Commander. Ready for your directive.";
    }

    const data = await res.json();
    return data.text || "Systems active, Sir.";
  } catch (e) {
    return language === 'hi'
      ? "हाँ सर, सिस्टम तैयार है। मैं आपकी क्या मदद कर सकती हूँ?"
      : language === 'hinglish'
      ? "Haan Sir, main sun rahi hoon. Sabhi systems ready hain."
      : "Communications link on standby, Sir. Ready for your directive.";
  }
}

export async function fetchTextToSpeech(
  text: string,
  voiceName: string = 'Kore'
): Promise<{ audio?: string; mimeType?: string; fallback?: boolean }> {
  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, voiceName }),
    });

    if (!res.ok) {
      return { fallback: true };
    }

    return await res.json();
  } catch (err) {
    console.warn('TTS request failed, using client fallback:', err);
    return { fallback: true };
  }
}

export async function generateAIImage(
  prompt: string,
  aspectRatio: string = '1:1'
): Promise<{ imageUrl: string; prompt: string; isSchematic?: boolean }> {
  const res = await fetch('/api/generate-image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, aspectRatio }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to generate visual schematic.');
  }

  return await res.json();
}

export async function analyzeVisionSnapshot(
  imageBase64: string,
  prompt?: string
): Promise<string> {
  const res = await fetch('/api/analyze-vision', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageBase64, prompt }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Vision analysis failed.');
  }

  const data = await res.json();
  return data.text;
}

export async function fetchTelemetry(): Promise<SystemTelemetry> {
  try {
    const res = await fetch('/api/telemetry');
    if (!res.ok) throw new Error('Telemetry offline');
    return await res.json();
  } catch {
    return {
      system: 'AURA OS v4.8.2',
      model: 'gemini-3.8-flash',
      status: 'LOCAL RUNTIME',
      arcReactorOutput: '98.8%',
      neuralBandwidth: '3.8 TB/s',
      tacticalUptime: 'ACTIVE',
    };
  }
}
