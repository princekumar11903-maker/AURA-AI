/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { HolographicAvatar } from './components/HolographicAvatar';
import { HUDHeader } from './components/HUDHeader';
import { ChatPanel } from './components/ChatPanel';
import { VisionHUD } from './components/VisionHUD';
import { ImageForge } from './components/ImageForge';
import { QuickActions } from './components/QuickActions';
import { SettingsModal } from './components/SettingsModal';
import { MobileDownloadModal } from './components/MobileDownloadModal';
import { audioService } from './services/audioService';
import { streamMessageFromGemini, sendMessageToGemini, fetchTextToSpeech } from './services/geminiService';
import { AvatarState, ChatMessage, UserSettings, LanguageMode } from './types';
import { User, MessageSquare, Camera, Sparkles, Activity } from 'lucide-react';

export default function App() {
  const [avatarState, setAvatarState] = useState<AvatarState>('idle');
  const [audioAmplitude, setAudioAmplitude] = useState<number>(0);
  const [micAmplitude, setMicAmplitude] = useState<number>(0);
  const [micFrequencies, setMicFrequencies] = useState<Uint8Array>(new Uint8Array(32));
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isOverdrive, setIsOverdrive] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'avatar' | 'chat' | 'vision' | 'forge' | 'actions'>('avatar');

  // Official Live & Shared App URLs for phone download & install
  const devUrl = 'https://ais-dev-5ic5hpf5nbb6ymcodjx6ja-319177386247.asia-northeast1.run.app';
  const sharedUrl = 'https://ais-pre-5ic5hpf5nbb6ymcodjx6ja-319177386247.asia-northeast1.run.app';

  // User Settings - Default language strictly Hindi with realistic neural voice (Aoede Studio)
  const [settings, setSettings] = useState<UserSettings>({
    language: 'hi',
    voiceName: 'Aoede',
    voiceEngine: 'neural', // Realistic Gemini 3.8 Flagship Neural Speech
    speechOutputEnabled: true,
    hologramGlow: 'med',
    showScanlines: true,
    speechRate: 1.0,
  });

  // Conversation history with Prince Sharma creator recognition
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-msg-1',
      role: 'model',
      text: 'A.U.R.A. ऑनलाइन है, सर! डेवलपर: प्रिंस शर्मा (Prince Sharma)। सभी सिस्टम्स 100% सामान्य हैं। बताइए मैं आपकी क्या सहायता करूँ?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [interimTranscript, setInterimTranscript] = useState<string>('');

  // Subscribe to audio amplitude for mouth animation & speech state listener
  useEffect(() => {
    const unsubscribe = audioService.onAmplitude((amp) => {
      setAudioAmplitude(amp);
    });

    audioService.setSpeakingStateListener((speaking) => {
      setAvatarState((prev) => {
        if (speaking) return 'speaking';
        if (prev === 'speaking') return 'idle';
        return prev;
      });
    });

    return () => {
      unsubscribe();
      audioService.setSpeakingStateListener(() => {});
    };
  }, []);

  // Update settings helper
  const handleUpdateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Instant vocalization for single utterance replay (Realistic Neural Studio Voice)
  const vocalizeText = useCallback(
    async (text: string) => {
      if (!settings.speechOutputEnabled) return;

      try {
        setAvatarState('speaking');
        audioService.unlockAudio();
        if (settings.voiceEngine === 'neural') {
          await audioService.vocalizeRealisticSpeech(text, settings.voiceName);
        } else {
          await audioService.speakBrowserSpeech(text, 'hi-IN', settings.speechRate);
        }
      } catch (err: any) {
        console.warn('Vocal synthesis error:', err);
      } finally {
        setAvatarState('idle');
      }
    },
    [settings]
  );

  // Send message with ultra-low latency streaming and realistic Hindi voice synthesis
  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    setErrorMessage(null);
    setInterimTranscript('');
    audioService.unlockAudio();
    audioService.clearSpeechQueue();

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const botMsgId = `model-${Date.now()}`;
    const botPlaceholder: ChatMessage = {
      id: botMsgId,
      role: 'model',
      text: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg, botPlaceholder]);
    setAvatarState('thinking');

    let accumulatedText = '';
    let sentenceBuffer = '';
    let hasStartedSpeaking = false;

    try {
      await streamMessageFromGemini(
        text,
        [...messages, userMsg],
        'hi', // Strictly Hindi
        (chunk) => {
          accumulatedText += chunk;
          sentenceBuffer += chunk;

          // Update message in real time on screen as tokens stream
          setMessages((prev) =>
            prev.map((m) => (m.id === botMsgId ? { ...m, text: accumulatedText } : m))
          );

          // Fast local browser vocalization if browser engine is selected
          if (settings.voiceEngine === 'browser') {
            const delimiterMatch = sentenceBuffer.match(/^([\s\S]*?[.!?।\n,])([\s\S]*)$/);
            if (delimiterMatch) {
              const sentenceToSpeak = delimiterMatch[1].trim();
              sentenceBuffer = delimiterMatch[2];

              if (sentenceToSpeak && settings.speechOutputEnabled) {
                if (!hasStartedSpeaking) {
                  setAvatarState('speaking');
                  hasStartedSpeaking = true;
                }
                audioService.enqueueStreamChunk(sentenceToSpeak, 'hi-IN', settings.speechRate);
              }
            } else if (sentenceBuffer.trim().split(/\s+/).length >= 4) {
              const words = sentenceBuffer.trim().split(/\s+/);
              const chunkToSpeak = words.slice(0, 4).join(' ');
              sentenceBuffer = words.slice(4).join(' ');

              if (chunkToSpeak && settings.speechOutputEnabled) {
                if (!hasStartedSpeaking) {
                  setAvatarState('speaking');
                  hasStartedSpeaking = true;
                }
                audioService.enqueueStreamChunk(chunkToSpeak, 'hi-IN', settings.speechRate);
              }
            }
          }
        }
      );

      // Play vocal response upon stream completion
      if (settings.speechOutputEnabled) {
        if (settings.voiceEngine === 'neural') {
          // Play ultra-realistic Gemini 3.8 studio voice
          setAvatarState('speaking');
          await audioService.vocalizeRealisticSpeech(accumulatedText.trim(), settings.voiceName);
          setAvatarState('idle');
        } else if (sentenceBuffer.trim()) {
          // Flush trailing browser chunks
          if (!hasStartedSpeaking) {
            setAvatarState('speaking');
          }
          audioService.enqueueStreamChunk(sentenceBuffer.trim(), 'hi-IN', settings.speechRate);
        }
      } else {
        setAvatarState('idle');
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      setErrorMessage(err?.message || 'Neural network link disruption.');
      setAvatarState('idle');
    }
  };

  // Toggle voice recognition with chest mic & mic button
  const handleToggleListening = () => {
    audioService.unlockAudio();

    if (isListening) {
      audioService.stopSpeechRecognition();
      setIsListening(false);
      if (interimTranscript.trim()) {
        const toSend = interimTranscript.trim();
        setInterimTranscript('');
        handleSendMessage(toSend);
      } else {
        setAvatarState('idle');
      }
    } else {
      setErrorMessage(null);
      setInterimTranscript('');
      setIsListening(true);
      setAvatarState('listening');

      const started = audioService.startSpeechRecognition(
        'hi',
        (interim) => {
          setInterimTranscript(interim);
        },
        (finalText) => {
          setInterimTranscript('');
          setIsListening(false);
          if (finalText.trim()) {
            handleSendMessage(finalText.trim());
          } else {
            setAvatarState('idle');
          }
        },
        (error) => {
          setErrorMessage(error);
          setIsListening(false);
          setAvatarState('idle');
          setInterimTranscript('');
        },
        () => {
          setIsListening(false);
          if (avatarState === 'listening') {
            setAvatarState('idle');
          }
        },
        (level, freqs) => {
          setMicAmplitude(level);
          setMicFrequencies(freqs);
        }
      );

      if (!started) {
        setIsListening(false);
        setAvatarState('idle');
      }
    }
  };

  // Quick Action Handlers
  const handleRunDiagnostic = () => {
    handleSendMessage('AURA, सिस्टम डायग्नोस्टिक रिपोर्ट दीजिए और अपनी स्थिति बताइए।');
  };

  const handleAskWeather = () => {
    handleSendMessage('AURA, आज का मौसम कैसा है?');
  };

  const handleAskDeveloper = () => {
    handleSendMessage('AURA, आपका डेवलपर कौन है और आपको किसने बनाया है?');
  };

  const handleTestVoice = () => {
    vocalizeText('नमस्ते प्रिंस शर्मा सर! मैं आपकी AI असिस्टेंट AURA बोल रही हूँ। मेरी आवाज़ अब बिल्कुल एक इंसान की तरह प्राकृतिक और मधुर है।');
  };

  const handleSelectLanguage = (lang: LanguageMode) => {
    handleUpdateSettings({ language: lang });
    if (lang === 'hi') {
      handleSendMessage('AURA, कृपया अब से हिन्दी में बात करें।');
    } else if (lang === 'hinglish') {
      handleSendMessage('AURA, please talk in Hinglish from now on.');
    } else {
      handleSendMessage('AURA, switch back to standard tactical English.');
    }
  };

  const handleToggleOverdrive = () => {
    const nextState = !isOverdrive;
    setIsOverdrive(nextState);
    handleUpdateSettings({
      hologramGlow: nextState ? 'high' : 'med',
    });
    // Temporary audio pulse
    vocalizeText(
      nextState
        ? 'Arc Reactor Overdrive activated, Sir. Output at 120 percent.'
        : 'Arc Reactor dialed back to standard cruise telemetry.'
    );
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: `init-${Date.now()}`,
        role: 'model',
        text: 'Communications log cleared, Sir. System standing by.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div className="relative min-h-screen bg-[#030712] text-cyan-400 flex flex-col justify-between overflow-x-hidden selection:bg-cyan-500 selection:text-black">
      {/* CRT Scanline overlay */}
      {settings.showScanlines && <div className="scanlines fixed inset-0 z-40" />}

      {/* Futuristic Background Atmospheric Lighting */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[140px]" />
        <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-blue-700/10 rounded-full blur-[120px]" />
      </div>

      {/* Top HUD Header */}
      <HUDHeader
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onTriggerDiagnostic={handleRunDiagnostic}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto p-2 sm:p-4 md:p-6 flex flex-col gap-4">
        {/* DESKTOP & TABLET VIEW: Dual/Triple Column Command Deck */}
        <div className="hidden lg:grid grid-cols-12 gap-5 flex-1 min-h-[580px]">
          {/* Left Column: Holographic Avatar Showcase Bay */}
          <div className="col-span-5 flex flex-col items-center justify-center p-4 rounded-2xl bg-black/40 border border-cyan-500/30 backdrop-blur-md relative shadow-2xl overflow-hidden group">
            {/* Top hologram status bar */}
            <div className="absolute top-3 left-4 right-4 flex justify-between items-center text-[10px] font-mono-tech text-cyan-500/80 border-b border-cyan-500/20 pb-1">
              <span>HOLOGRAPHIC PROJECTION BAY 01</span>
              <span className="text-cyan-300 font-bold">{isOverdrive ? 'OVERDRIVE ACTIVE' : 'STARK SECURE LINK'}</span>
            </div>

            {/* The Original SVG Avatar with animated lips, blinking, and chest mic */}
            <div className="w-full flex-1 flex items-center justify-center pt-4">
              <HolographicAvatar
                state={avatarState}
                audioAmplitude={audioAmplitude}
                glowIntensity={settings.hologramGlow}
                isListening={isListening}
                onToggleListening={handleToggleListening}
                className="w-full max-w-[460px]"
              />
            </div>

            {/* Bottom Avatar Controls / Telemetry */}
            <div className="w-full pt-2">
              <QuickActions
                onRunDiagnostic={handleRunDiagnostic}
                onSelectLanguage={handleSelectLanguage}
                onAskWeather={handleAskWeather}
                onAskDeveloper={handleAskDeveloper}
                onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
                onToggleOverdrive={handleToggleOverdrive}
                isOverdrive={isOverdrive}
                onClearChat={handleClearChat}
                onTestVoice={handleTestVoice}
              />
            </div>
          </div>

          {/* Right Column: Dynamic Tabs / Comms / Vision / Forge */}
          <div className="col-span-7 flex flex-col space-y-3">
            {/* Nav Deck Tabs */}
            <div className="flex items-center space-x-2 bg-black/50 p-1.5 rounded-xl border border-cyan-500/30 font-mono-tech text-xs">
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all ${
                  activeTab === 'chat' || activeTab === 'avatar'
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,243,255,0.6)]'
                    : 'text-cyan-400 hover:bg-cyan-950/60'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>COMMS HUD</span>
              </button>

              <button
                onClick={() => setActiveTab('vision')}
                className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all ${
                  activeTab === 'vision'
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,243,255,0.6)]'
                    : 'text-cyan-400 hover:bg-cyan-950/60'
                }`}
              >
                <Camera className="w-4 h-4" />
                <span>STARK VISION</span>
              </button>

              <button
                onClick={() => setActiveTab('forge')}
                className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all ${
                  activeTab === 'forge'
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,243,255,0.6)]'
                    : 'text-cyan-400 hover:bg-cyan-950/60'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>AI FORGE</span>
              </button>
            </div>

            {/* Tab Views */}
            <div className="flex-1 min-h-[500px]">
              {(activeTab === 'chat' || activeTab === 'avatar') && (
                <ChatPanel
                  messages={messages}
                  onSendMessage={handleSendMessage}
                  avatarState={avatarState}
                  isListening={isListening}
                  interimTranscript={interimTranscript}
                  onToggleListening={handleToggleListening}
                  micAmplitude={micAmplitude}
                  micFrequencies={micFrequencies}
                  onReplayAudio={(msg) => vocalizeText(msg.text)}
                  selectedLanguage={settings.language}
                  onChangeLanguage={(lang) => handleUpdateSettings({ language: lang })}
                  errorMessage={errorMessage}
                  onClearError={() => setErrorMessage(null)}
                />
              )}

              {activeTab === 'vision' && (
                <VisionHUD
                  onAnalysisResult={(resText) => {
                    handleSendMessage(`Tactical analysis of camera view: ${resText}`);
                  }}
                  onSetThinkingState={(isThinking) =>
                    setAvatarState(isThinking ? 'thinking' : 'idle')
                  }
                />
              )}

              {activeTab === 'forge' && (
                <ImageForge
                  onSetThinkingState={(isThinking) =>
                    setAvatarState(isThinking ? 'thinking' : 'idle')
                  }
                />
              )}
            </div>
          </div>
        </div>

        {/* MOBILE VIEW (Optimized for Android / Mobile screens first) */}
        <div className="lg:hidden flex flex-col flex-1 space-y-3 pb-16">
          {activeTab === 'avatar' && (
            <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-black/40 border border-cyan-500/30 backdrop-blur-md relative shadow-xl">
              <div className="w-full flex justify-between items-center text-[10px] font-mono-tech text-cyan-500/80 border-b border-cyan-500/20 pb-1 mb-2">
                <span>AURA HOLOGRAPHIC INTERFACE</span>
                <span className="text-cyan-300 font-bold">{isListening ? 'MIC ACTIVE' : avatarState.toUpperCase()}</span>
              </div>
              <div className="w-full max-w-[340px] aspect-[6/7]">
                <HolographicAvatar
                  state={avatarState}
                  audioAmplitude={audioAmplitude}
                  glowIntensity={settings.hologramGlow}
                  isListening={isListening}
                  onToggleListening={handleToggleListening}
                  className="w-full h-full"
                />
              </div>

              {/* Mobile Live Transcript Pill */}
              {isListening && (
                <div className="w-full mt-2 p-2 rounded-lg bg-emerald-950/70 border border-emerald-400/50 text-xs font-rajdhani text-white text-center animate-pulse">
                  {interimTranscript ? `"${interimTranscript}"` : "AURA sun rahi hai... boliye..."}
                </div>
              )}

              <div className="w-full mt-3">
                <QuickActions
                  onRunDiagnostic={handleRunDiagnostic}
                  onSelectLanguage={handleSelectLanguage}
                  onAskWeather={handleAskWeather}
                  onToggleOverdrive={handleToggleOverdrive}
                  isOverdrive={isOverdrive}
                  onClearChat={handleClearChat}
                />
              </div>
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="flex-1 min-h-[460px]">
              <ChatPanel
                messages={messages}
                onSendMessage={handleSendMessage}
                avatarState={avatarState}
                isListening={isListening}
                interimTranscript={interimTranscript}
                onToggleListening={handleToggleListening}
                micAmplitude={micAmplitude}
                micFrequencies={micFrequencies}
                onReplayAudio={(msg) => vocalizeText(msg.text)}
                selectedLanguage={settings.language}
                onChangeLanguage={(lang) => handleUpdateSettings({ language: lang })}
                errorMessage={errorMessage}
                onClearError={() => setErrorMessage(null)}
              />
            </div>
          )}

          {activeTab === 'vision' && (
            <div className="flex-1 min-h-[440px]">
              <VisionHUD
                onAnalysisResult={(resText) => {
                  handleSendMessage(`Tactical analysis of camera view: ${resText}`);
                }}
                onSetThinkingState={(isThinking) =>
                  setAvatarState(isThinking ? 'thinking' : 'idle')
                }
              />
            </div>
          )}

          {activeTab === 'forge' && (
            <div className="flex-1 min-h-[440px]">
              <ImageForge
                onSetThinkingState={(isThinking) =>
                  setAvatarState(isThinking ? 'thinking' : 'idle')
                }
              />
            </div>
          )}

          {activeTab === 'actions' && (
            <div className="space-y-4">
              <QuickActions
                onRunDiagnostic={handleRunDiagnostic}
                onSelectLanguage={handleSelectLanguage}
                onAskWeather={handleAskWeather}
                onAskDeveloper={handleAskDeveloper}
                onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
                onToggleOverdrive={handleToggleOverdrive}
                isOverdrive={isOverdrive}
                onClearChat={handleClearChat}
              />
            </div>
          )}
        </div>
      </main>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-black/90 backdrop-blur-lg border-t border-cyan-500/30 px-2 py-2 flex items-center justify-around font-mono-tech text-[10px]">
        <button
          onClick={() => setActiveTab('avatar')}
          className={`flex flex-col items-center space-y-1 p-1 rounded-lg transition-all ${
            activeTab === 'avatar'
              ? 'text-cyan-300 font-bold scale-105 text-glow-cyan'
              : 'text-cyan-600 hover:text-cyan-400'
          }`}
        >
          <User className="w-5 h-5" />
          <span>AVATAR</span>
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className={`flex flex-col items-center space-y-1 p-1 rounded-lg transition-all ${
            activeTab === 'chat'
              ? 'text-cyan-300 font-bold scale-105 text-glow-cyan'
              : 'text-cyan-600 hover:text-cyan-400'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span>COMMS</span>
        </button>

        <button
          onClick={() => setActiveTab('vision')}
          className={`flex flex-col items-center space-y-1 p-1 rounded-lg transition-all ${
            activeTab === 'vision'
              ? 'text-cyan-300 font-bold scale-105 text-glow-cyan'
              : 'text-cyan-600 hover:text-cyan-400'
          }`}
        >
          <Camera className="w-5 h-5" />
          <span>VISION</span>
        </button>

        <button
          onClick={() => setActiveTab('forge')}
          className={`flex flex-col items-center space-y-1 p-1 rounded-lg transition-all ${
            activeTab === 'forge'
              ? 'text-cyan-300 font-bold scale-105 text-glow-cyan'
              : 'text-cyan-600 hover:text-cyan-400'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span>FORGE</span>
        </button>

        <button
          onClick={() => setActiveTab('actions')}
          className={`flex flex-col items-center space-y-1 p-1 rounded-lg transition-all ${
            activeTab === 'actions'
              ? 'text-cyan-300 font-bold scale-105 text-glow-cyan'
              : 'text-cyan-600 hover:text-cyan-400'
          }`}
        >
          <Activity className="w-5 h-5" />
          <span>TACTICAL</span>
        </button>
      </nav>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onOpenDownloadModal={() => {
          setIsSettingsOpen(false);
          setIsDownloadModalOpen(true);
        }}
      />

      {/* Mobile Download & Installation Modal */}
      <MobileDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        devUrl={devUrl}
        sharedUrl={sharedUrl}
      />
    </div>
  );
}
