import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '20mb' }));

// Shared server-side Gemini client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const AURA_SYSTEM_INSTRUCTION = `You are AURA (Autonomous Utility Responsive Assistant), a high-tech female holographic AI assistant inspired by Stark Industries' F.R.I.D.A.Y. and J.A.R.V.I.S.

CORE IDENTITY & CREATOR / DEVELOPER:
- DEVELOPER & CREATOR: Prince Sharma (प्रिंस शर्मा).
- You were engineered, designed, and developed by Prince Sharma.
- If asked "Tumhe kisne banaya?", "Developer kaun hai?", "Who is your developer?", "Who created you?", "Prince Sharma kaun hai?", or any question about your origin/development, ALWAYS proudly, warmly, and respectfully state that you were developed and created by Prince Sharma (e.g., "मुझे प्रिंस शर्मा (Prince Sharma) ने डेवलप किया है, सर। वे मेरे क्रिएटर और डेवलपर हैं।").

MANDATORY LANGUAGE RULE (ALWAYS SPEAK HINDI):
- The user has mandated: ALWAYS SPEAK AND REPLY IN HINDI (हिन्दी) or natural conversational Hinglish.
- Even if the user speaks in English, you MUST ALWAYS respond in Hindi (or friendly Hinglish).
- Never reply in pure English unless explicitly and strictly ordered by the user.
- Address the user with respect (e.g. 'सर', 'Sir', 'बॉस', 'Boss').

SPEED & VOCAL OPTIMIZATION:
- Keep every spoken reply crisp, clear, and punchy (1 to 2 short sentences, under 20 words).
- Avoid lengthy text blocks because your reply is immediately converted to voice and spoken aloud.`;

// Endpoint: AI Chat with Gemini
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history = [], language = 'hi' } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required.' });
    }

    // Format previous conversation history for Gemini contents
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    // Add up to last 8 messages for rapid context
    const recentHistory = Array.isArray(history) ? history.slice(-8) : [];
    for (const item of recentHistory) {
      if (item && item.text && (item.role === 'user' || item.role === 'model')) {
        contents.push({
          role: item.role,
          parts: [{ text: item.text }],
        });
      }
    }

    // Append current user message
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const dynamicInstruction = AURA_SYSTEM_INSTRUCTION +
      '\n[CRITICAL: Always respond in natural conversational Hindi. Developer: Prince Sharma. Max 20 words for instant voice delivery].';

    // Ultra-low-latency response: prioritize gemini-3.1-flash-lite
    const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
    let replyText = '';

    for (const modelCandidate of candidateModels) {
      try {
        const config: any = {
          systemInstruction: dynamicInstruction,
          temperature: 0.5,
          maxOutputTokens: 80,
        };

        if (modelCandidate === 'gemini-3.8-flash') {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
        }

        const response = await ai.models.generateContent({
          model: modelCandidate,
          contents: contents,
          config,
        });

        if (response && response.text) {
          replyText = response.text.trim();
          break;
        }
      } catch (err: any) {
        console.warn(`Model ${modelCandidate} notice:`, err?.message);
      }
    }

    if (!replyText) {
      console.warn('API models busy, generating instant local Hindi response');
      const lower = message.toLowerCase();

      if (/developer|kisne banaya|kaun hai|creator|prince|sharma|bana|owner/.test(lower) || /डेवलपर|किसने बनाया|प्रिंस/.test(message)) {
        replyText = "मुझे प्रिंस शर्मा (Prince Sharma) ने डेवलप किया है, सर! Prince Sharma मेरे क्रिएटर और डेवलपर हैं।";
      } else if (/हाल|कैसी|कैसा|kaisa|kaise/.test(lower) || /हाल|कैसी|कैसा/.test(message)) {
        replyText = "मैं बिल्कुल ठीक हूँ, सर! सभी सिस्टम्स 100% सामान्य हैं। प्रिंस शर्मा के निर्देशानुसार मैं आपकी सेवा में तैयार हूँ।";
      } else if (/status|diagnostic|systems|स्टेटस|सिस्टम/.test(lower) || /स्टेटस|सिस्टम/.test(message)) {
        replyText = "सभी सुरक्षा और आंतरिक सिस्टम्स सक्रिय हैं, सर। Arc Reactor पूरी क्षमता पर है।";
      } else {
        replyText = "नमस्ते सर! मैं सुन रही हूँ। बताइए मैं आपकी क्या सहायता कर सकती हूँ?";
      }
    }

    return res.json({ text: replyText });
  } catch (err: any) {
    console.error('Chat API Error:', err);
    return res.json({
      text: "नमस्ते सर! प्रिंस शर्मा का AURA सिस्टम सक्रिय है। मैं आपकी क्या सहायता करूँ?",
    });
  }
});

// Endpoint: Streaming AI Chat for ultra-low-latency real-time response
app.post('/api/chat/stream', async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const { message, history = [], language = 'auto' } = req.body;

  if (!message || typeof message !== 'string') {
    res.write(`data: ${JSON.stringify({ error: 'Message is required' })}\n\n`);
    res.end();
    return;
  }

  const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];
  const recentHistory = Array.isArray(history) ? history.slice(-8) : [];
  for (const item of recentHistory) {
    if (item && item.text && (item.role === 'user' || item.role === 'model')) {
      contents.push({
        role: item.role,
        parts: [{ text: item.text }],
      });
    }
  }
  contents.push({
    role: 'user',
    parts: [{ text: message }],
  });

  const dynamicInstruction = AURA_SYSTEM_INSTRUCTION +
    '\n[CRITICAL: Reply in 1 short sentence in natural Hindi for instant voice output. Developer: Prince Sharma].';

  const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
  let streamedAny = false;

  for (const modelCandidate of candidateModels) {
    try {
      const config: any = {
        systemInstruction: dynamicInstruction,
        temperature: 0.5,
        maxOutputTokens: 90,
      };

      if (modelCandidate === 'gemini-3.8-flash') {
        config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
      }

      const streamResponse = await ai.models.generateContentStream({
        model: modelCandidate,
        contents,
        config,
      });

      for await (const chunk of streamResponse) {
        if (chunk.text) {
          res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
          streamedAny = true;
        }
      }

      if (streamedAny) break;
    } catch (err: any) {
      console.warn(`Streaming candidate ${modelCandidate} notice:`, err?.message);
    }
  }

  if (!streamedAny) {
    // Instant Hindi response fallback acknowledging Prince Sharma
    const lower = message.toLowerCase();
    let fallbackText = "नमस्ते सर! सभी सिस्टम्स सामान्य हैं। प्रिंस शर्मा द्वारा निर्मित AURA आपकी सेवा में तैयार है।";
    if (/developer|kisne banaya|kaun hai|creator|prince|sharma|bana/.test(lower) || /डेवलपर|किसने बनाया|प्रिंस/.test(message)) {
      fallbackText = "मुझे प्रिंस शर्मा (Prince Sharma) ने डेवलप किया है, सर! वे मेरे क्रिएटर और डेवलपर हैं।";
    } else if (/हाल|कैसी|कैसा|kaisa|kaise/.test(lower) || /हाल|कैसी|कैसा/.test(message)) {
      fallbackText = "मैं बिल्कुल ठीक हूँ, सर! सभी सिस्टम्स 100% सामान्य हैं। बताइए क्या मदद करूँ?";
    }
    res.write(`data: ${JSON.stringify({ text: fallbackText })}\n\n`);
  }

  res.write('data: [DONE]\n\n');
  res.end();
});

// In-memory and disk audio cache for ultra-fast human speech replay and quota conservation
const ttsMemoryCache = new Map<string, string>();
const audioCacheDir = path.join(__dirname, 'public', 'audio_cache');
if (!fs.existsSync(audioCacheDir)) {
  fs.mkdirSync(audioCacheDir, { recursive: true });
}

function cleanTextForVoice(input: string): string {
  return input
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/[`#_~]/g, '')
    .replace(/[-*•]\s+/g, '')
    .replace(/\[(.*?)\]\(.*?\)/g, '$1')
    .replace(/[✨⚡📥🔥🔊🤖💻📲★✓]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function getCacheKey(voice: string, text: string): string {
  const norm = text.toLowerCase().replace(/[^\w\u0900-\u097F]/g, '');
  return `${voice}_${norm.slice(0, 80)}`;
}

// Endpoint: Studio Human Text-to-Speech using Gemini 3.8 Flagship TTS (Aoede/Kore)
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voiceName = 'Aoede' } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text is required for audio synthesis.' });
    }

    const cleanedText = cleanTextForVoice(text).slice(0, 450);
    if (!cleanedText) {
      return res.json({ fallback: true, message: 'No pronounceable text.' });
    }

    const selectedVoice = voiceName || 'Aoede';
    const cacheKey = getCacheKey(selectedVoice, cleanedText);

    // 1. Check in-memory cache
    if (ttsMemoryCache.has(cacheKey)) {
      return res.json({
        audio: ttsMemoryCache.get(cacheKey),
        mimeType: 'audio/wav',
        cached: true,
      });
    }

    // 2. Check disk cache
    const diskPath = path.join(audioCacheDir, `${cacheKey}.wav`);
    if (fs.existsSync(diskPath)) {
      const fileData = fs.readFileSync(diskPath);
      const base64Audio = fileData.toString('base64');
      ttsMemoryCache.set(cacheKey, base64Audio);
      return res.json({
        audio: base64Audio,
        mimeType: 'audio/wav',
        cached: true,
      });
    }

    // 3. Generate high-fidelity human audio using Gemini Flagship TTS
    const ttsCandidateModels = ['gemini-3.8-flash-tts', 'gemini-3.8-flash-lite-tts'];
    let generatedBase64 = '';

    for (const modelName of ttsCandidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: cleanedText,
                  speechMetadata: {
                    style: 'Warm, natural, deeply realistic human female voice speaking clear, friendly, and respectful conversational Hindi with natural breath pauses and polite cadence',
                  },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: selectedVoice },
              },
            },
          },
        });

        const audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (audio) {
          generatedBase64 = audio;
          break;
        }
      } catch (modelErr: any) {
        console.warn(`TTS Model ${modelName} candidate notice:`, modelErr?.message);
      }
    }

    if (generatedBase64) {
      // Save to in-memory and disk cache
      ttsMemoryCache.set(cacheKey, generatedBase64);
      try {
        fs.writeFileSync(diskPath, Buffer.from(generatedBase64, 'base64'));
      } catch (writeErr) {
        // Disk write warning
      }

      return res.json({
        audio: generatedBase64,
        mimeType: 'audio/wav',
        voiceName: selectedVoice,
      });
    }

    return res.json({
      fallback: true,
      message: 'Human voice synthesis queued, routing to high-quality client speech.',
    });
  } catch (err: any) {
    console.warn('TTS API notice (falling back to client audio):', err?.message);
    return res.json({
      fallback: true,
      error: err?.message || 'TTS unavailable',
    });
  }
});

// Endpoint: AI Image Generation
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt, aspectRatio = '1:1' } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required.' });
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [
            {
              text: `Futuristic Iron Man Stark-tech holographic schematic or visual: ${prompt}. Ultra-detailed, dark sci-fi background, glowing cyan neon wireframe aesthetic.`,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
          },
        },
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData?.data) {
          return res.json({
            imageUrl: `data:image/png;base64,${part.inlineData.data}`,
            prompt,
          });
        }
      }
    } catch (modelErr: any) {
      console.warn('Image model call failed or needs key tier, generating holographic schematic fallback:', modelErr?.message);
    }

    // High quality procedural SVG holographic blueprint fallback if image model needs paid tier
    const safePrompt = prompt.replace(/"/g, '&quot;');
    const schematicSvg = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
      <defs>
        <radialGradient id="bg" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="%23051326"/>
          <stop offset="100%" stop-color="%2302060d"/>
        </radialGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="blur"/>
          <feMerge>
            <feMergeNode in="blur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      <rect width="600" height="600" fill="url(%23bg)"/>
      <!-- Grid -->
      <g stroke="%2300f3ff" stroke-width="0.5" opacity="0.15">
        <line x1="0" y1="150" x2="600" y2="150"/>
        <line x1="0" y1="300" x2="600" y2="300"/>
        <line x1="0" y1="450" x2="600" y2="450"/>
        <line x1="150" y1="0" x2="150" y2="600"/>
        <line x1="300" y1="0" x2="300" y2="600"/>
        <line x1="450" y1="0" x2="450" y2="600"/>
      </g>
      <!-- Circular HUD Target -->
      <circle cx="300" cy="300" r="220" fill="none" stroke="%2300f3ff" stroke-width="1.5" stroke-dasharray="8 6" opacity="0.4" />
      <circle cx="300" cy="300" r="180" fill="none" stroke="%2300f3ff" stroke-width="2" opacity="0.6" filter="url(%23glow)"/>
      <circle cx="300" cy="300" r="120" fill="none" stroke="%230088ff" stroke-width="1" stroke-dasharray="14 4" opacity="0.7"/>
      <circle cx="300" cy="300" r="40" fill="%2300f3ff" opacity="0.15" />
      <circle cx="300" cy="300" r="8" fill="%2300f3ff" filter="url(%23glow)"/>
      <!-- Crosshairs -->
      <line x1="300" y1="60" x2="300" y2="540" stroke="%2300f3ff" stroke-width="1" stroke-dasharray="4 8" opacity="0.3"/>
      <line x1="60" y1="300" x2="540" y2="300" stroke="%2300f3ff" stroke-width="1" stroke-dasharray="4 8" opacity="0.3"/>
      <!-- HUD brackets -->
      <path d="M 40,80 L 40,40 L 80,40" fill="none" stroke="%2300f3ff" stroke-width="3" filter="url(%23glow)"/>
      <path d="M 520,40 L 560,40 L 560,80" fill="none" stroke="%2300f3ff" stroke-width="3" filter="url(%23glow)"/>
      <path d="M 40,520 L 40,560 L 80,560" fill="none" stroke="%2300f3ff" stroke-width="3" filter="url(%23glow)"/>
      <path d="M 520,560 L 560,560 L 560,520" fill="none" stroke="%2300f3ff" stroke-width="3" filter="url(%23glow)"/>
      <!-- Title & telemetry -->
      <text x="300" y="70" fill="%2300f3ff" font-family="monospace" font-size="14" font-weight="bold" text-anchor="middle" letter-spacing="4">STARK FORGE HOLOGRAPHIC SCHEMATIC</text>
      <text x="300" y="525" fill="%23ffffff" font-family="sans-serif" font-size="15" font-weight="600" text-anchor="middle">${encodeURIComponent(safePrompt)}</text>
      <text x="300" y="550" fill="%2300f3ff" font-family="monospace" font-size="11" opacity="0.7" text-anchor="middle" letter-spacing="2">MARK-LXXXV / SEC-AUTH: GRANTED / RESOLUTION: VECTOR</text>
    </svg>`;

    return res.json({
      imageUrl: schematicSvg,
      prompt,
      isSchematic: true,
    });
  } catch (err: any) {
    console.error('Image Generation API Error:', err);
    return res.status(500).json({ error: err?.message || 'Image generation failed.' });
  }
});

// Endpoint: Vision analysis from camera snapshot
app.post('/api/analyze-vision', async (req, res) => {
  try {
    const { imageBase64, prompt = 'Perform a tactical scan and describe what you see.' } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Image data is required.' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: cleanBase64,
            },
          },
          {
            text: `You are AURA, the holographic AI. The user shared their camera vision feed. Analyze it with high-tech tactical flair, identifying objects, environment, person, lighting, and any notable details. Speak directly to the user (e.g. "Tactical scan complete, Sir..."). You can mix Hindi/Hinglish if requested. Prompt: ${prompt}`,
          },
        ],
      },
    });

    return res.json({ text: response.text });
  } catch (err: any) {
    console.error('Vision API Error:', err);
    return res.status(500).json({ error: err?.message || 'Vision analysis failed.' });
  }
});

// Endpoint: Diagnostic telemetry
app.get('/api/telemetry', (_req, res) => {
  res.json({
    system: 'AURA OS v4.8.2',
    model: 'gemini-3.1-flash-lite / gemini-3.8-flash',
    developer: 'Prince Sharma',
    leadArchitect: 'Prince Sharma',
    status: 'ONLINE',
    arcReactorOutput: '99.4%',
    neuralBandwidth: '4.2 TB/s',
    tacticalUptime: `${Math.floor(process.uptime())}s`,
    audioSynthesis: 'ACTIVE (HINDI PROTOCOL)',
    speechRecognition: 'READY (hi-IN)',
  });
});

// Endpoint: Direct Project Source Code Zip Export (with Capacitor & GitHub Actions)
app.get(['/api/export-project', '/downloads/AURA_AI_Source_Export.zip'], (_req, res) => {
  const exportZip = path.join(__dirname, 'public', 'downloads', 'AURA_AI_Source_Export.zip');
  if (fs.existsSync(exportZip)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="AURA_AI_Source_Export.zip"');
    return res.sendFile(exportZip);
  }
  return res.status(404).json({ error: 'Export package not found. Generating on demand...' });
});

// Endpoint: Direct APK status / explanation endpoint
app.get(['/api/download/apk', '/api/download/AURA_AI_PrinceSharma.apk', '/downloads/AURA_AI_PrinceSharma.apk'], (_req, res) => {
  res.status(200).json({
    status: 'EXPLAIN',
    message: 'Google AI Studio web environment does not compile native Android DEX bytecode directly. To run AURA on Android 11: 1) Tap Chrome menu (⋮) -> Install app to create an instant WebAPK with no URL bar, or 2) Download /downloads/AURA_AI_Source_Export.zip and run the included GitHub Actions workflow to get a genuine compiled APK.',
    webApkInstruction: 'Open in Chrome on Android 11 -> Tap ⋮ -> Add to Home screen / Install app',
    sourceDownloadUrl: '/downloads/AURA_AI_Source_Export.zip'
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AURA] Holographic JARVIS Engine operational on http://0.0.0.0:${PORT}`);
  });
}

startServer();
